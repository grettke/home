[source: http://extensions.libreoffice.org/extension-center/german-de-de-frami-dictionaries]

Spell checking
==============
de-DE_frami
Version: 2013-12-06
Author:  Franz Michael Baumann <fm.baumann@uni-muenster.de>
Based on igerman98 dictionary:
Version: 2013-12-06
Author:  Björn Jacke <bjoern@j3e.de>
         Download: http://www.j3e.de/ispell/igerman98/dict/
License: GNU GPL Version 2 or GPL Version 3 or OASIS 0.1

The frami dictionary contains the complete word list of igerman98 
and in addition numerous supplements by Franz Michael Baumann according to
the reform of 2006-08-01.
