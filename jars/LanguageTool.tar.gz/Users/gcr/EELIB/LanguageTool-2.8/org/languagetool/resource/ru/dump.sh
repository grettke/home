#/bin/sh
java -jar morfologik-tools-1.5.2-standalone.jar fsa_dump -x -d russian.dict >dump
